# TPC1: Análise de um Dataset
## 2024-02-09

## Autor:
- A100645
- Mateus Lemos Martins

## Resumo:

Neste trabalho, utilizou-se o material fornecido pelo docente, pelo que teremos de fazer o parse do mesmo em Python, criando os seguintes resultados:

- Lista ordenada alfabeticamente das modalidades desportivas;

- Percentagens de atletas aptos e inaptos para a prática desportiva;

- Distribuição de atletas por escalão etário (escalão = intervalo de 5 anos): ... [30-34], [35-39], ...
